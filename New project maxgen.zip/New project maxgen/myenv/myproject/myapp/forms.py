from django import forms
from .models import YourModel

class YourModelForm(forms.ModelForm):
    class Meta:
        model = YourModel
        fields = ['date_column_1', 'date_column_2', 'date_column_3', 'date_column_4']