# views.py
import pandas as pd
from django.shortcuts import render, redirect
from .forms import YourModelForm
from .models import *

def add_data_from_excel(request):
    superuser1 = User.objects.get(username='superuser1')
    superuser2 = User.objects.get(username='superuser2')
    superuser3 = User.objects.get(username='superuser3')
    superuser4 = User.objects.get(username='superuser4')
    if request.method == 'POST':
            excel_data = pd.read_excel(request.FILES['file'])
            print("ok",excel_data)
            # Loop through the rows and save data to the database
            
            for index, row in excel_data.iterrows():
                # print(row)
                print(row[excel_data.columns[0:4]].tolist())  
                existing_user = User1.objects.filter(first_name=row['First Name'], last_name=row['Last Name']).first()
                if not existing_user:
                    User1.objects.create(first_name= row['First Name'],last_name= row['Last Name'],age= row['Age'],gender= row['Gender'],created_by=superuser1 )   
                    Education.objects.create(school_name= row['School Name'],year_of_passing= row['Year of Passing'],college_name= row['College Name'],year_of_pass_clg= row['Year of Passing'],created_by=superuser2 )   
                    Work.objects.create(company_name= row['Company Name'],experience= row['Experience'],created_by=superuser3)   
                    Contact.objects.create(mobile= row['Mobile Number'],email= row['Email ID'],created_by=superuser4)   
            ex.objects.create(file=request.FILES['file'])
            data = {
                    'users': User1.objects.all(),
                    'educations': Education.objects.all(),
                    'works': Work.objects.all(),
                    'contacts': Contact.objects.all(),
                }

            context = {'data': data}
            return render(request, 'upload_excel.html', context)
#   Redirect to a success page
    else:
        return render(request, 'upload_excel.html')


# def add_data_from_excel(request):
#     uid=user_data.objects.all()
    
#     if request.method == 'POST':
#             excel_data = pd.read_excel(request.FILES['file'])
#             print("ok",excel_data)
#             # Loop through the rows and save data to the database
            
#             for index, row in excel_data.iterrows():
#                 # print(row)
#                 print(row[excel_data.columns[0:5]].tolist())  
#                 existing_user = user_data.objects.filter(first_name=row['First Name'], last_name=row['Last Name']).first()
#                 if not existing_user:
#                     user_data.objects.create(first_name= row['First Name'] ,last_name= row['Last Name'],
#                     age= row['Age'] ,gender= row['Gender'],school_name= row['School Name'],
#                     year_of_passing= row['Year of Passing'],college_name= row['College Name'],
#                     year_of_pass_clg= row['Year of Passing'],company_name= row['Company Name'],
#                     experience= row['Experience'],mobile= row['Mobile Number'],email= row['Email ID'] )   
                   
#             contaxt={
#             "uid":uid,
            
#         }
#             return render(request, 'upload_excel.html',contaxt)  # Redirect to a success page
#     else:
#         contaxt={
#             "uid":uid,
            
#         }

#         return render(request, 'upload_excel.html',contaxt)


def table(request):
    uid=User1.objects.all()
    eid=Education.objects.all()
    wid=Work.objects.all()
    cid=Contact.objects.all()
    contaxt={
        "uid":uid,
        "eid":eid,
        "wid":wid,
        "cid":cid,
    }
    return render(request, 'table.html',contaxt)

def login(request):
    # uid1=user_data.objects.all()
    uid1= User1.objects.all()
    eid1= Education.objects.all()
    wid1= Work.objects.all()
    cid1= Contact.objects.all()
    # print(uid1)
    if request.POST:
        print("ok1")
        email=request.POST['email']
        password=request.POST['password']
        if email=="superuser1" and password=="1":
            # request.session['email']=email
            uid1=User1.objects.all()
            contaxt={
              "a":1,
              "a0":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
            }
            
            return render(request, 'login.html',contaxt)
        elif email=="superuser2" and password=="2":
            eid1= Education.objects.all()
            contaxt={
              "a":1,
              "a1":1,
              "eid1":eid1,
              "uid1":uid1,
              "wid1":wid1,
              "cid1":cid1,
            }
            
            return render(request, 'login.html',contaxt)    
        elif email=="superuser3" and password=="3":
            wid1=Work.objects.all()
            contaxt={
              "a":1,
              "a2":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
            }
            
            return render(request, 'login.html',contaxt)  
        elif email=="superuser4" and password=="4":
            cid1=Contact.objects.all()
            contaxt={
              "a":1,
              "a3":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
            }
            
            return render(request, 'login.html',contaxt) 
        elif email=="admin" and password=="1":
            return redirect("admin_show")               
        else:    
            return render(request, 'login.html')
    else:
        # if "email" in request.session:        
        # contaxt={
        #     "a":1,
        #     "uid1":uid1
        # }        
        # return render(request, 'login.html',contaxt)
        # else:
        #     print("okdsdfs")
            return render(request, 'login.html')

             
"""
Excel find and store data in admin side 


"""        


# views.py
import pandas as pd
from django.shortcuts import render
from django.contrib.auth.models import User
from .models import user_data

def add_data_from_excel1(request):
    uid = user_data.objects.all()

    if request.method == 'POST':
        excel_data = pd.read_excel(request.FILES['file'])
        print("ok", excel_data)

        # Assuming you have superusers named 'superuser1' and 'superuser2'
        superuser1 = User.objects.get(username='superuser1')
        superuser2 = User.objects.get(username='superuser2')

        for index, row in excel_data.iterrows():
            # Check if a user with the same name already exists
            existing_user = user_data_input.objects.filter(first_name=row['First Name'], last_name=row['Last Name']).first()

            if not existing_user:
                if index % 2 == 0:  # Assign fields to superuser1
                    user_instance = user_data_input.objects.create(
                        first_name=row['First Name'],
                        last_name=row['Last Name'],
                        age=row['Age'],
                        gender=row['Gender'],
                        created_by=superuser1,
                    )
                else:  # Assign fields to superuser2
                    user_instance = user_data_input.objects.create(
                        first_name=row['First Name'],
                        last_name=row['Last Name'],
                        age=row['Age'],
                        gender=row['Gender'],
                        created_by=superuser2,
                        school_name=row['School Name'],
                        year_of_passing=row['Year of Passing'],
                        college_name=row['College Name'],
                        year_of_pass_clg=row['Year of Passing'],
                        company_name=row['Company Name'],
                        experience=row['Experience'],
                        mobile=row['Mobile Number'],
                        email=row['Email ID'],
                    )

        context = {
            "uid": uid,
        }
        return render(request, 'upload_excel.html', context)  # Redirect to a success page

    else:
        context = {
            "uid": uid,
        }
        return render(request, 'upload_excel.html', context)
# ================================================================

def edit1(request,id):
    
    uid = User1.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    file_path = r'C:\Users\Dell\Desktop\New project maxgen\myenv\myproject\img\SampleData.xlsx'
    df = pd.read_excel(file_path)
    if request.POST:
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        age = request.POST['age']
        gender = request.POST['gender']
        print(df.columns)
        index_to_update = df[df['First Name'] == uid.first_name].index[0]
        print(index_to_update)
        df.at[index_to_update, 'Age'] = age
        df.at[index_to_update, 'First Name'] = first_name
        df.at[index_to_update, 'Last Name'] = last_name
        df.at[index_to_update, 'Gender'] = gender
        df.to_excel(file_path, index=False)
        uid.first_name=first_name
        uid.last_name=last_name
        uid.age=age
        uid.gender=gender
        uid.save()
       
        contaxt={
              "a":1,
              "a0":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
        return render(request, 'login.html',contaxt) 
        # return redirect("login")
    else:
        contaxt={
            "uid":uid,
            "uid1":uid1,
            "eid1":eid1,
            "wid1":wid1,
            "cid1":cid1,
        }
        return render(request,"edit1.html",contaxt)


def edit2(request,id):
    
    uid = Education.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    if request.POST:
        school_name = request.POST['school_name']
        year_of_passing = request.POST['year_of_passing']
        college_name = request.POST['college_name']
        year_of_pass_clg = request.POST['year_of_pass_clg']
        
        uid.school_name=school_name
        uid.year_of_passing=year_of_passing
        uid.college_name=college_name
        uid.year_of_pass_clg=year_of_pass_clg
        uid.save()
        
        contaxt={
              "a":1,
              "a1":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
        return render(request, 'login.html',contaxt)
        # return redirect("login")
    else:
        contaxt={
            "uid":uid,
            
        }
        return render(request,"edit2.html",contaxt)




def edit3(request,id):
    uid = Work.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    
    if request.POST:
        company_name = request.POST['company_name']
        experience_name = request.POST['experience']
        
        uid.company_name=company_name
        uid.experience=experience_name
        uid.save()
        # return redirect("login")
        contaxt={
              "a":1,
              "a2":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
        return render(request, 'login.html',contaxt)
    else:
        contaxt={
            "uid":uid
        }
        return render(request,"edit3.html",contaxt)



def edit4(request,id):
    uid = Contact.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    
    
    if request.POST:
        mobile = request.POST['mobile']
        email = request.POST['email']
       
        uid.mobile=mobile
        uid.email=email
        uid.save()
        
        # return redirect("login")
        contaxt={
              "a":1,
              "a3":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
        return render(request, 'login.html',contaxt)
    else:
        contaxt={
            "uid":uid
        }
        return render(request,"edit4.html",contaxt)

def del1(request,id):
    uid = User1.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    uid.delete()
    contaxt={
              "a":1,
              "a0":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
    return render(request, 'login.html',contaxt) 
def del2(request,id):
    uid = Education.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    uid.delete()

    contaxt={
              "a":1,
              "a1":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
    return render(request, 'login.html',contaxt)
def del3(request,id):
    uid = Work.objects.get(id=id)
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all()
    uid.delete()

    contaxt={
              "a":1,
              "a2":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
    return render(request, 'login.html',contaxt)
def del4(request,id):
    uid = Contact.objects.get(id=id)   
    uid1=User1.objects.all()
    eid1=Education.objects.all()
    wid1=Work.objects.all()
    cid1=Contact.objects.all() 
    uid.delete()

    contaxt={
              "a":1,
              "a3":1,
              "uid1":uid1,
              "eid1":eid1,
              "wid1":wid1,
              "cid1":cid1,
              "uid":user_data.objects.all()
            }
            
    return render(request, 'login.html',contaxt)        


# def admin_show(request):
#     users = User1.objects.all()
#     education = Education.objects.all()
#     work = Work.objects.all()
#     contact = Contact.objects.all()

#     combined_data = zip(users, education, work, contact)

#     context = {
#         "combined_data": combined_data,
#     }

#     return render(request, 'admin_show.html', context)

def admin_show(request):
    uid=User1.objects.all()
    eid=Education.objects.all()
    wid=Work.objects.all()
    cid=Contact.objects.all()
    contaxt={
        "uid":uid,
        "eid":eid,
        "wid":wid,
        "cid":cid,
    }
    return render(request, 'admin_show.html',contaxt)

def admin_edit1(request,id):
    uid=User1.objects.get(id=id)
    if request.POST:
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        age = request.POST['age']
        gender = request.POST['gender']
        
        uid.first_name=first_name
        uid.last_name=last_name
        uid.age=age
        uid.gender=gender
        uid.save()
    return redirect(admin_show)
def admin_edit2(request,id):
    uid = Education.objects.get(id=id)
    if request.POST:
        school_name = request.POST['school_name']
        year_of_passing = request.POST['year_of_passing']
        college_name = request.POST['college_name']
        year_of_pass_clg = request.POST['year_of_pass_clg']
        
        uid.school_name=school_name
        uid.year_of_passing=year_of_passing
        uid.college_name=college_name
        uid.year_of_pass_clg=year_of_pass_clg
        uid.save()
    return redirect(admin_show)
def admin_edit3(request,id):
    uid = Work.objects.get(id=id)
    
    if request.POST:
        company_name = request.POST['company_name']
        experience_name = request.POST['experience']
        
        uid.company_name=company_name
        uid.experience=experience_name
        uid.save()
    return redirect(admin_show)
def admin_edit4(request,id):
    uid = Contact.objects.get(id=id)
    if request.POST:
        mobile = request.POST['mobile']
        email = request.POST['email']
       
        uid.mobile=mobile
        uid.email=email
        uid.save()
        
    return redirect(admin_show)            
def admin_del1(request,id):
    uid=User1.objects.get(id=id)
    uid.delete()
    return redirect(admin_show)
def admin_del2(request,id):
    uid=Education.objects.get(id=id)
    uid.delete()
    return redirect(admin_show)
def admin_del3(request,id):
    uid=Work.objects.get(id=id)
    uid.delete()
    return redirect(admin_show)
def admin_del4(request,id):
    uid=Contact.objects.get(id=id)
    uid.delete()
    return redirect(admin_show)


"""
superadmin login
superadmin wise edit
superadmin wise delete


"""



    



    