"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    
    path('add_data_from_excel/', views.add_data_from_excel, name='add_data_from_excel'),
    path('add_data_from_excel1/', views.add_data_from_excel1, name='add_data_from_excel1'),
    path('table', views.table, name='table'),
    path('login', views.login, name='login'),
    path('admin_show', views.admin_show, name='admin_show'),
    path('edit1/<int:id>', views.edit1, name='edit1'),
    path('edit2/<int:id>', views.edit2, name='edit2'),
    path('edit3/<int:id>', views.edit3, name='edit3'),
    path('edit4/<int:id>', views.edit4, name='edit4'),
    path('del1/<int:id>', views.del1, name='del1'),
    path('del2/<int:id>', views.del2, name='del2'),
    path('del3/<int:id>', views.del3, name='del3'),
    path('del4/<int:id>', views.del4, name='del4'),
   
    path('admin_del1/<int:id>', views.admin_del1, name='admin_del1'),
    path('admin_del2/<int:id>', views.admin_del2, name='admin_del2'),
    path('admin_del3/<int:id>', views.admin_del3, name='admin_del3'),
    path('admin_del4/<int:id>', views.admin_del4, name='admin_del4'),

    path('admin_edit1/<int:id>', views.admin_edit1, name='admin_edit1'),
    path('admin_edit2/<int:id>', views.admin_edit2, name='admin_edit2'),
    path('admin_edit3/<int:id>', views.admin_edit3, name='admin_edit3'),
    path('admin_edit4/<int:id>', views.admin_edit4, name='admin_edit4'),
    
 
    
]
