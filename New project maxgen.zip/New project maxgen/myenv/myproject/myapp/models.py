from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class YourModel(models.Model):
    date_column_1 = models.CharField(max_length=30)
    date_column_2 = models.CharField(max_length=30)
    date_column_3 = models.CharField(max_length=30)
    date_column_4 = models.CharField(max_length=30)

class User1(models.Model):
    first_name=models.CharField(max_length=50)
    last_name=models.CharField(max_length=50)
    age=models.CharField(max_length=30)
    gender=models.CharField(max_length=30)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

class Education(models.Model):
    school_name=models.CharField(max_length=50)
    year_of_passing=models.CharField(max_length=50)
    college_name=models.CharField(max_length=50)
    year_of_pass_clg=models.CharField(max_length=50)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
class Work(models.Model):
    company_name=models.CharField(max_length=50)
    experience=models.CharField(max_length=50)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
class Contact(models.Model):
    mobile=models.IntegerField()
    email=models.EmailField(max_length=50)    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)


class user_data(models.Model):
    first_name=models.CharField(max_length=50, blank=True, null=True)
    last_name=models.CharField(max_length=50, blank=True, null=True)
    age=models.CharField(max_length=30,blank=True,null=True)
    gender=models.CharField(max_length=30, blank=True, null=True)
    school_name=models.CharField(max_length=50, blank=True, null=True)
    year_of_passing=models.CharField(max_length=50, blank=True, null=True)
    college_name=models.CharField(max_length=50, blank=True, null=True)
    year_of_pass_clg=models.CharField(max_length=50, blank=True, null=True)
    company_name=models.CharField(max_length=50, blank=True, null=True)
    experience=models.CharField(max_length=50, blank=True, null=True)
    mobile=models.CharField(max_length=10,blank=True,null=True,default=0)
    email=models.EmailField(max_length=50, blank=True, null=True)

class user_data_input(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    age = models.IntegerField(blank=True,null=True)
    gender = models.CharField(max_length=30)
    school_name = models.CharField(max_length=50, blank=True, null=True)
    year_of_passing = models.CharField(max_length=50, blank=True, null=True)
    college_name = models.CharField(max_length=50, blank=True, null=True)
    year_of_pass_clg = models.CharField(max_length=50, blank=True, null=True)
    company_name = models.CharField(max_length=50, blank=True, null=True)
    experience = models.CharField(max_length=50, blank=True, null=True)
    mobile = models.IntegerField(blank=True, null=True)
    email = models.EmailField(max_length=50, blank=True, null=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"    

class ex(models.Model):
    file=models.FileField(upload_to='img')