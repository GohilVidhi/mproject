from django.contrib import admin
from .models import *

# Register your models here.

# admin.site.register(YourModel)
admin.site.register(User1)
admin.site.register(user_data)
admin.site.register(user_data_input)
admin.site.register(Education)
admin.site.register(Work)
admin.site.register(Contact)
admin.site.register(ex)